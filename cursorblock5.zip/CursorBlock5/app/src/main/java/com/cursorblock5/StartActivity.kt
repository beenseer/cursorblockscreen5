package com.cursorblock5

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Точка запуска «Cursor Block 5». Без окна: если служба специальных возможностей
 * включена, режим включается сразу и активность закрывается.
 * Если службы нет, открываются настройки с инструкцией.
 */
class StartActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = CursorAccessibilityService.instance
        if (svc != null) {
            if (!svc.active) svc.enableMode()
        } else {
            Toast.makeText(
                this,
                "Включите службу Cursor Block 5 в специальных возможностях",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
