package com.cursorblock5

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Фоновая служба активного режима: держит постоянное уведомление. */
class ModeService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannel(this)
        startForeground(NotificationHelper.ID, NotificationHelper.build(this))
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopForeground(true)
        super.onDestroy()
    }
}
