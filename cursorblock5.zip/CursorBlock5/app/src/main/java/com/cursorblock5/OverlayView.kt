package com.cursorblock5

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Один полноэкранный слой: рисует курсор и белую рамку выбранного элемента
 * и поглощает все касания, чтобы сенсор ничего не нажимал.
 * Палец, удержанный на курсоре HOLD_DISABLE_MS, отключает режим.
 */
class OverlayView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density

    var cursorX = -1f
        private set
    var cursorY = -1f
        private set

    /** Рамка выбранного элемента в координатах экрана. */
    var focusRect: Rect? = null

    /** Вызывается, когда палец удержан на курсоре нужное время. */
    var onHoldComplete: (() -> Unit)? = null

    private val loc = IntArray(2)
    private val cursorPath = Path()
    private val ringRect = RectF()

    private var holdActive = false
    private var holdStart = 0L
    private var holdX = 0f
    private var holdY = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
    }
    private val frameOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 6f * d
    }
    private val frameInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }

    private val holdTick = object : Runnable {
        override fun run() {
            if (!holdActive) return
            val elapsed = SystemClock.uptimeMillis() - holdStart
            if (elapsed >= Config.HOLD_DISABLE_MS) {
                holdActive = false
                invalidate()
                onHoldComplete?.invoke()
            } else {
                invalidate()
                postDelayed(this, 80L)
            }
        }
    }

    init {
        isClickable = true
        setWillNotDraw(false)
        buildCursor()
    }

    private fun buildCursor() {
        val s = 1.15f * d
        cursorPath.reset()
        cursorPath.moveTo(0f, 0f)
        cursorPath.lineTo(0f, 17f * s)
        cursorPath.lineTo(4.2f * s, 13.2f * s)
        cursorPath.lineTo(7.6f * s, 20.5f * s)
        cursorPath.lineTo(10.4f * s, 19.3f * s)
        cursorPath.lineTo(7.1f * s, 12.1f * s)
        cursorPath.lineTo(12.4f * s, 12.1f * s)
        cursorPath.close()
    }

    private fun hitsCursor(x: Float, y: Float): Boolean =
        x >= cursorX - 24f * d && x <= cursorX + 36f * d &&
            y >= cursorY - 24f * d && y <= cursorY + 48f * d

    private fun startHold(x: Float, y: Float) {
        holdActive = true
        holdStart = SystemClock.uptimeMillis()
        holdX = x
        holdY = y
        removeCallbacks(holdTick)
        post(holdTick)
    }

    private fun cancelHold() {
        if (holdActive) {
            holdActive = false
            removeCallbacks(holdTick)
            invalidate()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (hitsCursor(event.x, event.y)) startHold(event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (holdActive && hypot(event.x - holdX, event.y - holdY) > 24f * d) cancelHold()
            }
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> cancelHold()
        }
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean = true

    override fun onDetachedFromWindow() {
        removeCallbacks(holdTick)
        holdActive = false
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (cursorX < 0f) {
            cursorX = w / 2f
            cursorY = h / 2f
        } else {
            cursorX = cursorX.coerceIn(0f, (w - 1).toFloat())
            cursorY = cursorY.coerceIn(0f, (h - 1).toFloat())
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        val w = right - left
        val h = bottom - top
        val edge = (40 * d).toInt()
        val maxH = minOf(h, (200 * d).toInt())
        systemGestureExclusionRects = listOf(
            Rect(0, 0, edge, maxH),
            Rect(w - edge, 0, w, maxH)
        )
    }

    fun moveCursor(x: Float, y: Float) {
        cursorX = x.coerceIn(0f, (width - 1).coerceAtLeast(0).toFloat())
        cursorY = y.coerceIn(0f, (height - 1).coerceAtLeast(0).toFloat())
        invalidate()
    }

    /** Положение курсора в координатах экрана. */
    fun cursorScreen(): Point {
        getLocationOnScreen(loc)
        return Point(loc[0] + cursorX.toInt(), loc[1] + cursorY.toInt())
    }

    /** Переместить курсор в точку в координатах экрана. */
    fun moveCursorToScreen(x: Int, y: Int) {
        getLocationOnScreen(loc)
        moveCursor((x - loc[0]).toFloat(), (y - loc[1]).toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(loc)
        focusRect?.let { r ->
            val pad = 2f * d
            val rr = RectF(
                r.left - loc[0] - pad,
                r.top - loc[1] - pad,
                r.right - loc[0] + pad,
                r.bottom - loc[1] + pad
            )
            canvas.drawRoundRect(rr, 4f * d, 4f * d, frameOuter)
            canvas.drawRoundRect(rr, 4f * d, 4f * d, frameInner)
        }
        if (cursorX >= 0f) {
            if (holdActive) {
                val frac = ((SystemClock.uptimeMillis() - holdStart).toFloat() /
                    Config.HOLD_DISABLE_MS).coerceIn(0f, 1f)
                val cx = cursorX + 6f * d
                val cy = cursorY + 12f * d
                val r = 24f * d
                ringRect.set(cx - r, cy - r, cx + r, cy + r)
                canvas.drawArc(ringRect, -90f, 360f * frac, false, frameOuter)
                canvas.drawArc(ringRect, -90f, 360f * frac, false, frameInner)
            }
            canvas.save()
            canvas.translate(cursorX, cursorY)
            canvas.drawPath(cursorPath, fill)
            canvas.drawPath(cursorPath, outline)
            canvas.restore()
        }
    }
}
