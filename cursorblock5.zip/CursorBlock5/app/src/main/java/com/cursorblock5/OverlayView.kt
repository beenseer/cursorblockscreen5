package com.cursorblock5

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Один полноэкранный слой: рисует курсор и белую рамку выбранного элемента
 * и поглощает все касания, чтобы сенсор ничего не нажимал.
 */
class OverlayView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density

    var cursorX = -1f
        private set
    var cursorY = -1f
        private set

    /** Рамка выбранного элемента в координатах экрана. */
    var focusRect: Rect? = null

    private val loc = IntArray(2)
    private val cursorPath = Path()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
    }
    private val frameOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 6f * d
    }
    private val frameInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }

    init {
        isClickable = true
        setWillNotDraw(false)
        buildCursor()
    }

    private fun buildCursor() {
        val s = 1.15f * d
        cursorPath.reset()
        cursorPath.moveTo(0f, 0f)
        cursorPath.lineTo(0f, 17f * s)
        cursorPath.lineTo(4.2f * s, 13.2f * s)
        cursorPath.lineTo(7.6f * s, 20.5f * s)
        cursorPath.lineTo(10.4f * s, 19.3f * s)
        cursorPath.lineTo(7.1f * s, 12.1f * s)
        cursorPath.lineTo(12.4f * s, 12.1f * s)
        cursorPath.close()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = true

    override fun onGenericMotionEvent(event: MotionEvent): Boolean = true

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (cursorX < 0f) {
            cursorX = w / 2f
            cursorY = h / 2f
        } else {
            cursorX = cursorX.coerceIn(0f, (w - 1).toFloat())
            cursorY = cursorY.coerceIn(0f, (h - 1).toFloat())
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        val w = right - left
        val h = bottom - top
        val edge = (40 * d).toInt()
        val maxH = minOf(h, (200 * d).toInt())
        systemGestureExclusionRects = listOf(
            Rect(0, 0, edge, maxH),
            Rect(w - edge, 0, w, maxH)
        )
    }

    fun moveCursor(x: Float, y: Float) {
        cursorX = x.coerceIn(0f, (width - 1).coerceAtLeast(0).toFloat())
        cursorY = y.coerceIn(0f, (height - 1).coerceAtLeast(0).toFloat())
        invalidate()
    }

    /** Положение курсора в координатах экрана. */
    fun cursorScreen(): Point {
        getLocationOnScreen(loc)
        return Point(loc[0] + cursorX.toInt(), loc[1] + cursorY.toInt())
    }

    /** Переместить курсор в точку в координатах экрана. */
    fun moveCursorToScreen(x: Int, y: Int) {
        getLocationOnScreen(loc)
        moveCursor((x - loc[0]).toFloat(), (y - loc[1]).toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(loc)
        focusRect?.let { r ->
            val pad = 2f * d
            val rr = RectF(
                r.left - loc[0] - pad,
                r.top - loc[1] - pad,
                r.right - loc[0] + pad,
                r.bottom - loc[1] + pad
            )
            canvas.drawRoundRect(rr, 4f * d, 4f * d, frameOuter)
            canvas.drawRoundRect(rr, 4f * d, 4f * d, frameInner)
        }
        if (cursorX >= 0f) {
            canvas.save()
            canvas.translate(cursorX, cursorY)
            canvas.drawPath(cursorPath, fill)
            canvas.drawPath(cursorPath, outline)
            canvas.restore()
        }
    }
}
