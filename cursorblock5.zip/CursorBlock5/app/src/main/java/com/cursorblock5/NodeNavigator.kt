package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.graphics.Point
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import android.view.accessibility.AccessibilityWindowInfo
import kotlin.math.abs

enum class ScrollResult { SCROLLED, AT_END, NONE }

/** Поиск элементов интерфейса через Accessibility, переходы между ними и прокрутка. */
class NodeNavigator(private val svc: AccessibilityService) {

    class Item(val rect: Rect, val node: AccessibilityNodeInfo)

    private class Mover(val node: AccessibilityNodeInfo, val actionId: Int)

    private val actUp = AccessibilityAction.ACTION_SCROLL_UP.id
    private val actDown = AccessibilityAction.ACTION_SCROLL_DOWN.id
    private val actLeft = AccessibilityAction.ACTION_SCROLL_LEFT.id
    private val actRight = AccessibilityAction.ACTION_SCROLL_RIGHT.id

    private fun roots(systemUiOnly: Boolean): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        val wins = svc.windows
        if (wins == null || wins.isEmpty()) {
            svc.rootInActiveWindow?.let { list.add(it) }
            return list
        }
        for (w in wins) {
            if (w.type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue
            val r = w.root ?: continue
            if (systemUiOnly && r.packageName?.toString() != "com.android.systemui") continue
            list.add(r)
        }
        return list
    }

    // ------------------------------------------------------------------
    // Сбор элементов
    // ------------------------------------------------------------------

    fun collect(systemUiOnly: Boolean): List<Item> {
        val out = ArrayList<Item>()
        val seen = HashSet<String>()
        val dm = svc.resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val minSide = (8 * dm.density).toInt()
        for (root in roots(systemUiOnly)) walk(root, 0, out, seen, screen, minSide)
        out.sortWith(compareBy<Item>({ it.rect.top }, { it.rect.left }))
        return out
    }

    private fun isInteractive(n: AccessibilityNodeInfo): Boolean {
        if (n.isClickable || n.isLongClickable || n.isCheckable || n.isEditable) return true
        for (a in n.actionList) {
            if (a.id == AccessibilityNodeInfo.ACTION_CLICK ||
                a.id == AccessibilityNodeInfo.ACTION_LONG_CLICK
            ) return true
        }
        return n.isFocusable && n.childCount == 0
    }

    private fun walk(
        n: AccessibilityNodeInfo,
        depth: Int,
        out: MutableList<Item>,
        seen: MutableSet<String>,
        screen: Rect,
        minSide: Int
    ) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (isInteractive(n)) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.intersect(screen) && r.width() >= minSide && r.height() >= minSide) {
                val area = r.width().toLong() * r.height().toLong()
                val screenArea = screen.width().toLong() * screen.height().toLong()
                if (area <= screenArea * 85 / 100) {
                    val key = "${r.left},${r.top},${r.right},${r.bottom}"
                    if (seen.add(key)) out.add(Item(r, n))
                }
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1, out, seen, screen, minSide)
        }
    }

    // ------------------------------------------------------------------
    // Навигация в сторону нажатой стрелки
    // ------------------------------------------------------------------

    /**
     * Ищет ближайший элемент строго в заданном направлении (как FocusFinder в Android).
     * cur: рамка текущего элемента или маленький прямоугольник в точке курсора;
     * null: берётся элемент, ближайший к курсору.
     */
    fun navigate(dir: Dir, cur: Rect?, cursor: Point, systemUiOnly: Boolean): Item? {
        val items = collect(systemUiOnly)
        if (items.isEmpty()) return null
        if (cur == null) return items[indexOfNearest(items, cursor.x, cursor.y)]

        val cx = cur.centerX()
        val cy = cur.centerY()
        var best: Item? = null
        var bestScore = Long.MAX_VALUE
        loop@ for (it in items) {
            val r = it.rect
            if (r == cur) continue@loop
            val dx = r.centerX() - cx
            val dy = r.centerY() - cy
            var major = 0
            var minor = 0
            var beam = false
            when (dir) {
                Dir.DOWN -> {
                    if (dy <= 0) continue@loop
                    major = dy
                    minor = abs(dx)
                    beam = r.left < cur.right && r.right > cur.left
                }
                Dir.UP -> {
                    if (dy >= 0) continue@loop
                    major = -dy
                    minor = abs(dx)
                    beam = r.left < cur.right && r.right > cur.left
                }
                Dir.RIGHT -> {
                    if (dx <= 0) continue@loop
                    major = dx
                    minor = abs(dy)
                    beam = r.top < cur.bottom && r.bottom > cur.top
                }
                Dir.LEFT -> {
                    if (dx >= 0) continue@loop
                    major = -dx
                    minor = abs(dy)
                    beam = r.top < cur.bottom && r.bottom > cur.top
                }
            }
            var score = 13L * major * major + minor.toLong() * minor
            if (!beam) score *= 4L
            if (score < bestScore) {
                bestScore = score
                best = it
            }
        }
        return best
    }

    private fun indexOfNearest(items: List<Item>, x: Int, y: Int): Int {
        var best = 0
        var bestD = Long.MAX_VALUE
        for ((i, it) in items.withIndex()) {
            val dx = (it.rect.centerX() - x).toLong()
            val dy = (it.rect.centerY() - y).toLong()
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = i
            }
        }
        return best
    }

    // ------------------------------------------------------------------
    // Прокрутка
    // ------------------------------------------------------------------

    private fun gatherScrollable(n: AccessibilityNodeInfo, depth: Int, out: MutableList<AccessibilityNodeInfo>) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (n.isScrollable) out.add(n)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            gatherScrollable(c, depth + 1, out)
        }
    }

    /**
     * Вертикальная прокрутка содержимого. Учитываются только узлы, которые умеют
     * ехать вертикально именно в нужную сторону (горизонтальные пейджеры пропускаются).
     * Если задана точка, берётся самый вложенный узел под ней, иначе самый большой.
     *
     * SCROLLED: прокрутили. AT_END: прокручиваемый список есть, но дальше некуда.
     * NONE: прокручиваемых по вертикали узлов нет вообще.
     */
    fun scroll(down: Boolean, x: Int?, y: Int?, systemUiOnly: Boolean): ScrollResult {
        val all = ArrayList<AccessibilityNodeInfo>()
        for (r in roots(systemUiOnly)) gatherScrollable(r, 0, all)
        if (all.isEmpty()) return ScrollResult.NONE

        val wantDir = if (down) actDown else actUp
        val wantGeneric = if (down) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }

        val movers = ArrayList<Mover>()
        var verticalCapable = false
        for (n in all) {
            val ids = n.actionList.map { it.id }
            val hasUp = actUp in ids
            val hasDown = actDown in ids
            val hasHoriz = actLeft in ids || actRight in ids
            val hasGeneric = AccessibilityNodeInfo.ACTION_SCROLL_FORWARD in ids ||
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD in ids
            val directional = hasUp || hasDown
            if (!directional && !(hasGeneric && !hasHoriz)) continue
            verticalCapable = true
            val id = if (directional) wantDir else wantGeneric
            if (id in ids) movers.add(Mover(n, id))
        }
        if (movers.isEmpty()) return if (verticalCapable) ScrollResult.AT_END else ScrollResult.NONE

        val rect = Rect()
        val ordered = ArrayList<Mover>()
        if (x != null && y != null) {
            val under = movers.filter {
                it.node.getBoundsInScreen(rect)
                rect.contains(x, y)
            }.sortedBy {
                it.node.getBoundsInScreen(rect)
                rect.width().toLong() * rect.height().toLong()
            }
            ordered.addAll(under)
        }
        val rest = movers.filter { it !in ordered }.sortedByDescending {
            it.node.getBoundsInScreen(rect)
            rect.width().toLong() * rect.height().toLong()
        }
        ordered.addAll(rest)

        for (m in ordered) {
            if (m.node.performAction(m.actionId)) return ScrollResult.SCROLLED
        }
        return ScrollResult.AT_END
    }
}
