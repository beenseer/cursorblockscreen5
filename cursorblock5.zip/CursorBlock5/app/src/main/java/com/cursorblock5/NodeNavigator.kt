package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.graphics.Point
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/** Поиск элементов интерфейса через Accessibility и переходы между ними. */
class NodeNavigator(private val svc: AccessibilityService) {

    class Item(val rect: Rect, val node: AccessibilityNodeInfo)

    private fun roots(systemUiOnly: Boolean): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        val wins = svc.windows
        if (wins == null || wins.isEmpty()) {
            svc.rootInActiveWindow?.let { list.add(it) }
            return list
        }
        for (w in wins) {
            if (w.type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue
            val r = w.root ?: continue
            if (systemUiOnly && r.packageName?.toString() != "com.android.systemui") continue
            list.add(r)
        }
        return list
    }

    fun collect(): List<Item> {
        val out = ArrayList<Item>()
        val seen = HashSet<String>()
        val dm = svc.resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels.toLong()
        for (root in roots(false)) walk(root, 0, out, seen, screenArea)
        out.sortWith(compareBy<Item>({ it.rect.top }, { it.rect.left }))
        return out
    }

    private fun walk(
        n: AccessibilityNodeInfo,
        depth: Int,
        out: MutableList<Item>,
        seen: MutableSet<String>,
        screenArea: Long
    ) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (n.isClickable || n.isLongClickable || n.isCheckable || n.isEditable) {
            val r = Rect()
            n.getBoundsInScreen(r)
            val area = r.width().toLong() * r.height().toLong()
            if (r.width() > 0 && r.height() > 0 && area <= screenArea * 85 / 100) {
                val key = "${r.left},${r.top},${r.right},${r.bottom}"
                if (seen.add(key)) out.add(Item(r, n))
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1, out, seen, screenArea)
        }
    }

    /**
     * Следующий элемент в заданном направлении. Если рамки ещё нет,
     * выбирается элемент, ближайший к курсору.
     */
    fun navigate(dir: Dir, current: Rect?, cursor: Point): Item? {
        val items = collect()
        if (items.isEmpty()) return null
        if (current == null) {
            return items[indexOfNearest(items, cursor.x, cursor.y)]
        }
        var idx = items.indexOfFirst { it.rect == current }
        if (idx < 0) idx = indexOfNearest(items, current.centerX(), current.centerY())
        return when (dir) {
            Dir.DOWN -> items.getOrNull(idx + 1)
            Dir.UP -> items.getOrNull(idx - 1)
            Dir.RIGHT -> horizontal(items, idx, current, true) ?: items.getOrNull(idx + 1)
            Dir.LEFT -> horizontal(items, idx, current, false) ?: items.getOrNull(idx - 1)
        }
    }

    private fun horizontal(items: List<Item>, idx: Int, cur: Rect, right: Boolean): Item? {
        var best: Item? = null
        var bestDist = Int.MAX_VALUE
        for ((i, it) in items.withIndex()) {
            if (i == idx) continue
            val overlap = minOf(it.rect.bottom, cur.bottom) - maxOf(it.rect.top, cur.top)
            if (overlap <= 0) continue
            val diff = if (right) it.rect.centerX() - cur.centerX() else cur.centerX() - it.rect.centerX()
            if (diff <= 0) continue
            if (diff < bestDist) {
                bestDist = diff
                best = it
            }
        }
        return best
    }

    private fun indexOfNearest(items: List<Item>, x: Int, y: Int): Int {
        var best = 0
        var bestD = Long.MAX_VALUE
        for ((i, it) in items.withIndex()) {
            val dx = (it.rect.centerX() - x).toLong()
            val dy = (it.rect.centerY() - y).toLong()
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = i
            }
        }
        return best
    }

    private fun gatherScrollable(n: AccessibilityNodeInfo, depth: Int, out: MutableList<AccessibilityNodeInfo>) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (n.isScrollable) out.add(n)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            gatherScrollable(c, depth + 1, out)
        }
    }

    /**
     * Реальная прокрутка содержимого. Если задана точка, берётся самый
     * вложенный прокручиваемый элемент под ней, иначе самый большой.
     */
    fun scroll(forward: Boolean, x: Int?, y: Int?, systemUiOnly: Boolean): Boolean {
        val all = ArrayList<AccessibilityNodeInfo>()
        for (r in roots(systemUiOnly)) gatherScrollable(r, 0, all)
        if (all.isEmpty()) return false
        val rect = Rect()
        var target: AccessibilityNodeInfo? = null
        if (x != null && y != null) {
            var bestA = Long.MAX_VALUE
            for (n in all) {
                n.getBoundsInScreen(rect)
                if (rect.contains(x, y)) {
                    val a = rect.width().toLong() * rect.height().toLong()
                    if (a < bestA) {
                        bestA = a
                        target = n
                    }
                }
            }
        }
        if (target == null) {
            var bestA = -1L
            for (n in all) {
                n.getBoundsInScreen(rect)
                val a = rect.width().toLong() * rect.height().toLong()
                if (a > bestA) {
                    bestA = a
                    target = n
                }
            }
        }
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return target?.performAction(action) ?: false
    }
}
