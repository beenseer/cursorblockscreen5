package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.graphics.Point
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import android.view.accessibility.AccessibilityWindowInfo
import kotlin.math.abs

enum class ScrollResult { SCROLLED, AT_END, NONE }

/** Поиск элементов интерфейса через Accessibility, переходы между ними и прокрутка. */
class NodeNavigator(private val svc: AccessibilityService) {

    companion object {
        const val SYSTEMUI = "com.android.systemui"
    }

    class Item(val rect: Rect, val node: AccessibilityNodeInfo)

    private class Mover(val node: AccessibilityNodeInfo, val actionId: Int)

    private val actUp = AccessibilityAction.ACTION_SCROLL_UP.id
    private val actDown = AccessibilityAction.ACTION_SCROLL_DOWN.id
    private val actLeft = AccessibilityAction.ACTION_SCROLL_LEFT.id
    private val actRight = AccessibilityAction.ACTION_SCROLL_RIGHT.id

    /**
     * Корни окон. systemUiOnly = true: только окна SystemUI (открытая шторка).
     * false: все окна, кроме SystemUI (обычные приложения), чтобы строка состояния
     * и панель навигации не мешали выбору.
     */
    private fun roots(systemUiOnly: Boolean): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        val wins = svc.windows
        if (wins == null || wins.isEmpty()) {
            svc.rootInActiveWindow?.let { list.add(it) }
            return list
        }
        for (w in wins) {
            if (w.type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue
            val r = w.root ?: continue
            val sys = r.packageName?.toString() == SYSTEMUI
            if (sys != systemUiOnly) continue
            list.add(r)
        }
        return list
    }

    /**
     * Открыта ли шторка: в Android 11 окно SystemUI растягивается почти на весь
     * экран, пока шторка выдвинута, и сжимается до высоты строки состояния, когда она закрыта.
     */
    fun isShadeOpen(): Boolean {
        val wins = svc.windows ?: return false
        val dm = svc.resources.displayMetrics
        val limit = dm.heightPixels * 0.6f
        val rect = Rect()
        for (w in wins) {
            val t = w.type
            if (t == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY ||
                t == AccessibilityWindowInfo.TYPE_INPUT_METHOD
            ) continue
            w.getBoundsInScreen(rect)
            if (rect.height() < limit) continue
            if (w.root?.packageName?.toString() == SYSTEMUI) return true
        }
        return false
    }

    // ------------------------------------------------------------------
    // Сбор элементов
    // ------------------------------------------------------------------

    fun collect(systemUiOnly: Boolean): List<Item> {
        val out = ArrayList<Item>()
        val dm = svc.resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        val minSide = (8 * dm.density).toInt()
        val tol = (3 * dm.density).toInt()
        for (root in roots(systemUiOnly)) {
            val weak = Config.isWeakPackage(root.packageName?.toString())
            walk(root, 0, out, weak, screen, minSide, tol)
        }
        out.sortWith(compareBy<Item>({ it.rect.top }, { it.rect.left }))
        return out
    }

    private fun isInteractive(n: AccessibilityNodeInfo, weak: Boolean): Boolean {
        if (n.isClickable || n.isLongClickable || n.isCheckable || n.isEditable) return true
        if (!weak) return false
        for (a in n.actionList) {
            if (a.id == AccessibilityNodeInfo.ACTION_CLICK ||
                a.id == AccessibilityNodeInfo.ACTION_LONG_CLICK
            ) return true
        }
        return n.isFocusable && n.childCount == 0
    }

    private fun nearDuplicate(out: List<Item>, r: Rect, tol: Int): Boolean {
        for (item in out) {
            val o = item.rect
            if (abs(o.left - r.left) <= tol && abs(o.top - r.top) <= tol &&
                abs(o.right - r.right) <= tol && abs(o.bottom - r.bottom) <= tol
            ) return true
        }
        return false
    }

    private fun walk(
        n: AccessibilityNodeInfo,
        depth: Int,
        out: MutableList<Item>,
        weak: Boolean,
        screen: Rect,
        minSide: Int,
        tol: Int
    ) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (isInteractive(n, weak)) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.intersect(screen) && r.width() >= minSide && r.height() >= minSide) {
                val area = r.width().toLong() * r.height().toLong()
                val screenArea = screen.width().toLong() * screen.height().toLong()
                if (area <= screenArea * 85 / 100 && !nearDuplicate(out, r, tol)) {
                    out.add(Item(r, n))
                }
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1, out, weak, screen, minSide, tol)
        }
    }

    // ------------------------------------------------------------------
    // Навигация в сторону нажатой стрелки
    // ------------------------------------------------------------------

    /**
     * Ищет ближайший элемент строго в заданном направлении (как FocusFinder в Android).
     * cur: рамка текущего элемента или маленький прямоугольник в точке курсора;
     * null: берётся элемент, ближайший к курсору.
     */
    fun navigate(dir: Dir, cur: Rect?, cursor: Point, systemUiOnly: Boolean): Item? {
        val items = collect(systemUiOnly)
        if (items.isEmpty()) return null
        if (cur == null) return items[indexOfNearest(items, cursor.x, cursor.y)]

        val cx = cur.centerX()
        val cy = cur.centerY()
        var best: Item? = null
        var bestScore = Long.MAX_VALUE
        loop@ for (item in items) {
            val r = item.rect
            if (r == cur) continue@loop
            val dx = r.centerX() - cx
            val dy = r.centerY() - cy
            var major = 0
            var minor = 0
            var beam = false
            when (dir) {
                Dir.DOWN -> {
                    if (dy <= 0) continue@loop
                    major = dy
                    minor = abs(dx)
                    beam = r.left < cur.right && r.right > cur.left
                }
                Dir.UP -> {
                    if (dy >= 0) continue@loop
                    major = -dy
                    minor = abs(dx)
                    beam = r.left < cur.right && r.right > cur.left
                }
                Dir.RIGHT -> {
                    if (dx <= 0) continue@loop
                    major = dx
                    minor = abs(dy)
                    beam = r.top < cur.bottom && r.bottom > cur.top
                }
                Dir.LEFT -> {
                    if (dx >= 0) continue@loop
                    major = -dx
                    minor = abs(dy)
                    beam = r.top < cur.bottom && r.bottom > cur.top
                }
            }
            var score = 13L * major * major + minor.toLong() * minor
            if (!beam) score *= 4L
            if (score < bestScore) {
                bestScore = score
                best = item
            }
        }
        return best
    }

    private fun indexOfNearest(items: List<Item>, x: Int, y: Int): Int {
        var best = 0
        var bestD = Long.MAX_VALUE
        for ((i, item) in items.withIndex()) {
            val dx = (item.rect.centerX() - x).toLong()
            val dy = (item.rect.centerY() - y).toLong()
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = i
            }
        }
        return best
    }

    // ------------------------------------------------------------------
    // Прокрутка
    // ------------------------------------------------------------------

    private fun gatherScrollable(n: AccessibilityNodeInfo, depth: Int, out: MutableList<AccessibilityNodeInfo>) {
        if (depth > 60) return
        if (!n.isVisibleToUser) return
        if (n.isScrollable) out.add(n)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            gatherScrollable(c, depth + 1, out)
        }
    }

    /**
     * Прокрутка содержимого в сторону dir (вниз показывает то, что ниже, вправо то, что правее).
     * Используются только направленные действия SCROLL_UP/DOWN/LEFT/RIGHT, поэтому
     * горизонтальный пейджер главного экрана не листается от вертикальной команды.
     * Если задана точка, берётся самый вложенный узел под ней, иначе самый большой.
     *
     * SCROLLED: прокрутили. AT_END: подходящий узел есть, но дальше некуда.
     * NONE: узлов с такой осью прокрутки нет вообще (тогда вызывающий может прокрутить жестом).
     */
    fun scroll(dir: Dir, x: Int?, y: Int?, systemUiOnly: Boolean): ScrollResult {
        val all = ArrayList<AccessibilityNodeInfo>()
        for (r in roots(systemUiOnly)) gatherScrollable(r, 0, all)
        if (all.isEmpty()) return ScrollResult.NONE

        val vertical = dir == Dir.UP || dir == Dir.DOWN
        val axisA = if (vertical) actUp else actLeft
        val axisB = if (vertical) actDown else actRight
        val want = when (dir) {
            Dir.UP -> actUp
            Dir.DOWN -> actDown
            Dir.LEFT -> actLeft
            Dir.RIGHT -> actRight
        }

        val movers = ArrayList<Mover>()
        var capable = false
        for (n in all) {
            val ids = n.actionList.map { it.id }
            if (axisA !in ids && axisB !in ids) continue
            capable = true
            if (want in ids) movers.add(Mover(n, want))
        }
        if (movers.isEmpty()) return if (capable) ScrollResult.AT_END else ScrollResult.NONE

        val rect = Rect()
        val ordered = ArrayList<Mover>()
        if (x != null && y != null) {
            val under = movers.filter {
                it.node.getBoundsInScreen(rect)
                rect.contains(x, y)
            }.sortedBy {
                it.node.getBoundsInScreen(rect)
                rect.width().toLong() * rect.height().toLong()
            }
            ordered.addAll(under)
        }
        val rest = movers.filter { it !in ordered }.sortedByDescending {
            it.node.getBoundsInScreen(rect)
            rect.width().toLong() * rect.height().toLong()
        }
        ordered.addAll(rest)

        for (m in ordered) {
            if (m.node.performAction(m.actionId)) return ScrollResult.SCROLLED
        }
        return ScrollResult.AT_END
    }
}
