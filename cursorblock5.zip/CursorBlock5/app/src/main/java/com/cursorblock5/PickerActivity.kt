package com.cursorblock5

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.inputmethod.InputMethodManager

/**
 * Прозрачная активность: открывает стандартный системный выбор клавиатуры.
 * Пока окно выбора открыто, стрелки и OK работают штатно (сам диалог их понимает).
 */
class PickerActivity : Activity() {

    private var shown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CursorAccessibilityService.instance?.beginPassThrough()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !shown) {
            shown = true
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
            finish()
        }
    }
}
