package com.cursorblock5

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var statusView: TextView? = null
    private var keyView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Запуск кнопкой 9: если служба уже включена и режим выключен, включаем сразу.
        val svc = CursorAccessibilityService.instance
        if (svc != null && !svc.active) {
            svc.enableMode()
            finish()
            return
        }
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 15f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        col.addView(text("Cursor Block 5", 24f, true))

        val st = text("")
        statusView = st
        col.addView(st)

        col.addView(button("Включить режим") {
            val s = CursorAccessibilityService.instance
            if (s == null) {
                Toast.makeText(this, "Сначала включите службу специальных возможностей", Toast.LENGTH_LONG).show()
            } else {
                s.enableMode()
                finish()
            }
        })
        col.addView(button("Отключить режим") {
            CursorAccessibilityService.instance?.disableMode()
            refresh()
        })
        col.addView(button("1. Служба специальных возможностей") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2. Разрешение «Поверх других приложений»") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("3. Работа в фоне (оптимизация батареи)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(text(
            "Первая настройка: включите Cursor Block 5 в «Специальные возможности» " +
                "(Установленные службы), подтвердите запрос. Для курсора достаточно этой службы; " +
                "разрешение «Поверх других приложений» выдайте по желанию. " +
                "В настройках батареи для приложения выберите «Не ограничивать». " +
                "После этого назначьте запуск Cursor Block 5 на длинное нажатие кнопки 9 — " +
                "режим будет включаться сам.",
            14f
        ))
        col.addView(text("Управление", 18f, true))
        col.addView(text(
            "D-pad, короткое нажатие: переход к ближайшему элементу в сторону стрелки, выбранный элемент в белой рамке.\n" +
                "D-pad, удержание: курсор движется с ускорением; у края экрана и в шторке список прокручивается.\n" +
                "Удерживая стрелку, нажмите цифру: вправо+6, влево+4, вниз+0, вверх+2. Это свайп экрана в эту сторону (листание экранов, вкладок, списков).\n" +
                "OK, короткое: левый клик. OK, длинное: правый клик / контекстное меню.\n" +
                "Кнопка 7, длинное: открыть шторку. Ещё раз длинное 7: полные быстрые настройки.\n" +
                "В окне выбора клавиатуры стрелки и OK работают штатно.\n" +
                "Остальные кнопки (ввод текста) работают как обычно.",
            14f
        ))
        col.addView(text("Аварийное отключение", 18f, true))
        col.addView(text(
            "Удерживайте BACK + OK одновременно 3 секунды.\n" +
                "Или прикоснитесь пальцем к курсору и держите 15 секунд: вокруг курсора заполняется кольцо, потом режим отключается.",
            14f
        ))
        col.addView(text("Проверка кодов клавиш (режим должен быть выключен)", 18f, true))
        val kv = text("Нажмите любую кнопку телефона.", 14f)
        keyView = kv
        col.addView(kv)

        return ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(col)
        }
    }

    private fun refresh() {
        val s = CursorAccessibilityService.instance
        val sb = StringBuilder()
        sb.append("Служба специальных возможностей: ")
            .append(if (s != null) "включена" else "ВЫКЛЮЧЕНА").append('\n')
        sb.append("Поверх других приложений: ")
            .append(if (Settings.canDrawOverlays(this)) "разрешено" else "не выдано (необязательно)").append('\n')
        sb.append("Режим курсора: ")
            .append(if (s != null && s.active) "ВКЛЮЧЁН" else "выключен")
        statusView?.text = sb.toString()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        keyView?.text = "Код клавиши: $keyCode (${KeyEvent.keyCodeToString(keyCode)})"
        return super.onKeyDown(keyCode, event)
    }
}
