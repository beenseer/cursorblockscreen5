package com.cursorblock5

import android.accessibilityservice.AccessibilityService

/** Открывает настоящую системную шторку уведомлений без свайпа. */
object ShadeController {
    fun open(svc: AccessibilityService): Boolean =
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
}
