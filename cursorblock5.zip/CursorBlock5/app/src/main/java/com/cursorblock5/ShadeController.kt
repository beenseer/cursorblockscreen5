package com.cursorblock5

import android.accessibilityservice.AccessibilityService

/** Открывает настоящую системную шторку и быстрые настройки без свайпа. */
object ShadeController {
    fun open(svc: AccessibilityService): Boolean =
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)

    /** Раскрывает полную панель быстрых настроек (все плитки). */
    fun openQuickSettings(svc: AccessibilityService): Boolean =
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
}
