package com.cursorblock5

import android.view.KeyEvent

enum class Dir { UP, DOWN, LEFT, RIGHT }

/** Все временные и скоростные параметры в одном месте. */
object Config {
    /** Сколько держать кнопку направления, чтобы это считалось длинным нажатием. */
    const val DIR_LONG_MS = 350L
    /** Длинное нажатие OK (правый клик). */
    const val OK_LONG_MS = 600L
    /** Длинное нажатие кнопки 7 (шторка). */
    const val KEY7_LONG_MS = 700L
    /** Автоотключение при неподвижном курсоре. */
    const val IDLE_TIMEOUT_MS = 10_000L
    /** BACK + OK для аварийного отключения. */
    const val EMERGENCY_MS = 3_000L

    const val TICK_MS = 16L
    const val MIN_SPEED_DP = 50f
    const val MAX_SPEED_DP = 800f
    const val ACCEL_MS = 2000f

    const val EDGE_ZONE_DP = 56f
    const val SCROLL_INTERVAL_MS = 400L

    const val TAP_MS = 50L
    const val LONG_TAP_MS = 800L
}

/**
 * Карта физических клавиш. Если на Qin F21 Pro коды отличаются,
 * правьте только этот объект (коды видно на главном экране приложения,
 * когда режим выключен: нажмите кнопку и прочитайте код).
 */
object KeyMap {
    val UP: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_UP)
    val DOWN: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_DOWN)
    val LEFT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_LEFT)
    val RIGHT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_RIGHT)
    val OK: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_CENTER)
    const val BACK = KeyEvent.KEYCODE_BACK
    const val SHADE = KeyEvent.KEYCODE_7
}
