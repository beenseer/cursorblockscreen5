package com.cursorblock5

import android.view.KeyEvent

enum class Dir { UP, DOWN, LEFT, RIGHT }

/** Все временные и скоростные параметры в одном месте. */
object Config {
    /** Сколько держать кнопку направления, чтобы это считалось длинным нажатием. */
    const val DIR_LONG_MS = 350L
    /** Длинное нажатие OK (правый клик). */
    const val OK_LONG_MS = 600L
    /** Длинное нажатие кнопки 7 (шторка). */
    const val KEY7_LONG_MS = 700L
    /** Сколько держать палец на курсоре, чтобы отключить режим. */
    const val HOLD_DISABLE_MS = 15_000L
    /** BACK + OK для аварийного отключения. */
    const val EMERGENCY_MS = 3_000L
    /** Окно для комбо, когда цифра нажата чуть раньше стрелки. */
    const val COMBO_WINDOW_MS = 400L

    const val TICK_MS = 16L
    const val MIN_SPEED_DP = 50f
    const val MAX_SPEED_DP = 800f
    const val ACCEL_MS = 2000f

    const val EDGE_ZONE_DP = 56f
    const val SCROLL_INTERVAL_MS = 300L

    const val TAP_MS = 50L
    const val LONG_TAP_MS = 800L
    const val SWIPE_MS = 220L

    /**
     * false: комбо "вправо+6" открывает правый экран (палец едет справа налево).
     * true: палец едет в ту же сторону, что и стрелка.
     */
    const val SWIPE_FINGER_FOLLOWS_DIRECTION = false
}

/**
 * Карта физических клавиш. Если на Qin F21 Pro коды отличаются,
 * правьте только этот объект.
 */
object KeyMap {
    val UP: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_UP)
    val DOWN: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_DOWN)
    val LEFT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_LEFT)
    val RIGHT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_RIGHT)
    val OK: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_CENTER)
    const val BACK = KeyEvent.KEYCODE_BACK
    val SHADE: Set<Int> = setOf(KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7)

    /** Цифра, которая вместе с удержанной стрелкой даёт свайп. */
    val SWIPE_DIGITS: Map<Int, Dir> = mapOf(
        KeyEvent.KEYCODE_6 to Dir.RIGHT,
        KeyEvent.KEYCODE_NUMPAD_6 to Dir.RIGHT,
        KeyEvent.KEYCODE_4 to Dir.LEFT,
        KeyEvent.KEYCODE_NUMPAD_4 to Dir.LEFT,
        KeyEvent.KEYCODE_0 to Dir.DOWN,
        KeyEvent.KEYCODE_NUMPAD_0 to Dir.DOWN,
        KeyEvent.KEYCODE_2 to Dir.UP,
        KeyEvent.KEYCODE_NUMPAD_2 to Dir.UP
    )

    fun swipeDir(code: Int): Dir? = SWIPE_DIGITS[code]
}
