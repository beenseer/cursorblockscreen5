package com.cursorblock5

import android.view.KeyEvent

enum class Dir { UP, DOWN, LEFT, RIGHT }

/** Все временные и скоростные параметры в одном месте. */
object Config {
    /** Сколько держать кнопку направления, чтобы это считалось длинным нажатием. */
    const val DIR_LONG_MS = 350L
    /** Длинное нажатие OK (правый клик). */
    const val OK_LONG_MS = 600L
    /** Сколько держать стрелку вниз вместе с 0, чтобы открылась шторка. */
    const val SHADE_COMBO_MS = 500L
    /** Сколько держать палец на курсоре, чтобы отключить режим. */
    const val HOLD_DISABLE_MS = 15_000L
    /** BACK + OK для аварийного отключения. */
    const val EMERGENCY_MS = 3_000L
    /** Окно для комбо, когда цифра нажата чуть раньше стрелки. */
    const val COMBO_WINDOW_MS = 400L

    const val TICK_MS = 16L
    const val MIN_SPEED_DP = 50f
    const val MAX_SPEED_DP = 800f
    const val ACCEL_MS = 2000f

    /** Зона у края экрана, где удержание стрелки начинает прокручивать содержимое. */
    const val EDGE_ZONE_DP = 40f
    /** Сколько курсор должен постоять у края, прежде чем начнётся прокрутка. */
    const val EDGE_DWELL_MS = 350L
    const val SCROLL_INTERVAL_MS = 380L

    const val TAP_MS = 50L
    const val LONG_TAP_MS = 800L

    /** Свайп комбинацией: длительность и длина (доля экрана) от точки курсора. */
    const val SWIPE_MS = 260L
    const val SWIPE_DISTANCE = 0.45f

    /**
     * Горизонтальные комбо: false = вправо+6 открывает правый экран (палец идёт справа налево).
     * true = палец идёт в ту же сторону, что и стрелка.
     */
    const val SWIPE_H_FINGER_FOLLOWS_DIRECTION = false

    /**
     * Вертикальные комбо: true = вниз+8 тянет палец вниз (так открывается шторка и
     * раскрываются быстрые настройки). false = палец идёт в противоположную сторону.
     */
    const val SWIPE_V_FINGER_FOLLOWS_DIRECTION = true

    /**
     * Приложения, у которых самописный интерфейс: там выбираются и менее очевидные
     * элементы (не только clickable). В остальных приложениях берутся только
     * обычные нажимаемые элементы, это даёт более точные рамки.
     */
    val WEAK_PACKAGES: Set<String> = setOf(
        "com.android.systemui",
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "org.telegram.plus",
        "org.thunderdog.challegram",
        "com.exteragram.messenger",
        "uz.unnarsx.cherrygram",
        "tw.nekomimi.nekogram"
    )

    fun isWeakPackage(pkg: String?): Boolean =
        pkg != null && (pkg in WEAK_PACKAGES || pkg.contains("telegram", ignoreCase = true))
}

/**
 * Карта физических клавиш. Если на Qin F21 Pro коды отличаются,
 * правьте только этот объект.
 */
object KeyMap {
    val UP: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_UP)
    val DOWN: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_DOWN)
    val LEFT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_LEFT)
    val RIGHT: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_RIGHT)
    val OK: Set<Int> = setOf(KeyEvent.KEYCODE_DPAD_CENTER)
    const val BACK = KeyEvent.KEYCODE_BACK
    /** Шторка: удерживать стрелку вниз и 0 одновременно. */
    val SHADE_DIGITS: Set<Int> = setOf(KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0)

    /** Цифра, которая вместе с удержанной стрелкой даёт свайп (вправо 6, влево 4, вниз 8, вверх 2). */
    val SWIPE_DIGITS: Map<Int, Dir> = mapOf(
        KeyEvent.KEYCODE_6 to Dir.RIGHT,
        KeyEvent.KEYCODE_NUMPAD_6 to Dir.RIGHT,
        KeyEvent.KEYCODE_4 to Dir.LEFT,
        KeyEvent.KEYCODE_NUMPAD_4 to Dir.LEFT,
        KeyEvent.KEYCODE_8 to Dir.DOWN,
        KeyEvent.KEYCODE_NUMPAD_8 to Dir.DOWN,
        KeyEvent.KEYCODE_2 to Dir.UP,
        KeyEvent.KEYCODE_NUMPAD_2 to Dir.UP
    )

    fun swipeDir(code: Int): Dir? = SWIPE_DIGITS[code]
}
