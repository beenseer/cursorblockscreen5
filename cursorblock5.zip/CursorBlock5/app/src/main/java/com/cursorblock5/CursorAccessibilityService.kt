package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Ядро приложения: фильтрует физические кнопки, рисует курсор и блокирующий слой,
 * выполняет клики, навигацию, прокрутку, свайпы и открытие шторки.
 */
class CursorAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CursorAccessibilityService? = null

        private const val SYSTEMUI = "com.android.systemui"
        private const val ANDROID_PKG = "android"
    }

    private class TextSnap(val text: String, val selStart: Int, val selEnd: Int)

    /** Цифровая клавиша, нажатие которой уже ушло в приложение (нужно для отката текста). */
    private class HeldKey(val code: Int, val time: Long, val snap: TextSnap?)

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: OverlayView? = null
    private var navigator: NodeNavigator? = null
    private var density = 1f

    @Volatile
    var active = false
        private set

    // ---- D-pad ----
    private var pressedDir: Dir? = null
    private var dirLongFired = false
    private var dirComboUsed = false
    private var movingDir: Dir? = null
    private var moveStart = 0L
    private var lastTick = 0L
    private var lastScroll = 0L

    // ---- OK / BACK ----
    private var okDown = false
    private var backDown = false
    private var okLongFired = false
    private var okSuppressed = false
    private var comboFired = false
    private var swallowBackUp = false

    // ---- цифры: 7 (шторка) и 6/4/0/2 (свайпы) ----
    private var held: HeldKey? = null
    private val swallowedKeys = HashSet<Int>()
    private var repeatSwallow = -1

    // ---- состояние ----
    private var focusNode: AccessibilityNodeInfo? = null
    private var shadeOpen = false
    private var passThrough = false
    private var passThroughUntil = 0L
    private var touchSeq = 0

    private val dirLongRunnable = Runnable {
        val d = pressedDir
        if (d != null && !dirComboUsed) {
            dirLongFired = true
            startMoving(d)
        }
    }

    private val okLongRunnable = Runnable {
        okLongFired = true
        performRightClick()
    }

    private val key7Runnable = Runnable { onKey7Long() }

    private val comboRunnable = Runnable {
        comboFired = true
        swallowBackUp = backDown
        disableMode()
    }

    private val moveRunnable = object : Runnable {
        override fun run() {
            val dir = movingDir ?: return
            val v = overlay ?: return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastTick).coerceAtLeast(1L) / 1000f
            lastTick = now
            val t = ((now - moveStart).toFloat() / Config.ACCEL_MS).coerceIn(0f, 1f)
            val eased = t * t * (3f - 2f * t)
            val speed = (Config.MIN_SPEED_DP + (Config.MAX_SPEED_DP - Config.MIN_SPEED_DP) * eased) * density
            val step = speed * dt
            var x = v.cursorX
            var y = v.cursorY
            when (dir) {
                Dir.UP -> y -= step
                Dir.DOWN -> y += step
                Dir.LEFT -> x -= step
                Dir.RIGHT -> x += step
            }
            v.moveCursor(x, y)
            maybeScroll(dir, v)
            handler.postDelayed(this, Config.TICK_MS)
        }
    }

    // ------------------------------------------------------------------
    // Жизненный цикл службы
    // ------------------------------------------------------------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        navigator = NodeNavigator(this)
        density = resources.displayMetrics.density
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!active || event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            if (pkg == SYSTEMUI || pkg == packageName || pkg == ANDROID_PKG) return
            // Открылось обычное приложение: шторка и окно выбора клавиатуры закрыты.
            shadeOpen = false
            passThrough = false
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        disableMode()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        disableMode()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Включение и выключение режима
    // ------------------------------------------------------------------

    fun enableMode() {
        if (active) return
        val manager = wm ?: return
        val v = OverlayView(this)
        v.onHoldComplete = { handler.post { disableMode() } }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            manager.addView(v, lp)
        } catch (e: Exception) {
            return
        }
        overlay = v
        resetKeyState()
        shadeOpen = false
        active = true
        try {
            startForegroundService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // уведомление не критично для работы режима
        }
    }

    fun disableMode() {
        handler.removeCallbacksAndMessages(null)
        val v = overlay
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // слой уже удалён
            }
        }
        overlay = null
        focusNode = null
        resetKeyState()
        shadeOpen = false
        passThrough = false
        active = false
        try {
            stopService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // служба уже остановлена
        }
    }

    private fun resetKeyState() {
        pressedDir = null
        dirLongFired = false
        dirComboUsed = false
        movingDir = null
        okDown = false
        backDown = false
        okLongFired = false
        okSuppressed = false
        comboFired = false
        held = null
        swallowedKeys.clear()
        repeatSwallow = -1
        touchSeq++
    }

    /** Вызывается, когда открыто системное окно выбора клавиатуры. */
    fun beginPassThrough() {
        if (!active) return
        handler.removeCallbacks(dirLongRunnable)
        stopMoving()
        pressedDir = null
        dirComboUsed = false
        passThrough = true
        passThroughUntil = SystemClock.uptimeMillis() + 60_000L
        shadeOpen = false
    }

    // ------------------------------------------------------------------
    // Фильтр физических кнопок
    // ------------------------------------------------------------------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN

        // После аварийного отключения глотаем отпускание BACK, чтобы не было лишнего «назад».
        if (swallowBackUp && code == KeyMap.BACK && !down) {
            swallowBackUp = false
            return true
        }
        if (!active) return false

        if (passThrough && SystemClock.uptimeMillis() > passThroughUntil) passThrough = false

        return when {
            code == KeyMap.BACK -> onBack(event, down)
            code in KeyMap.OK -> onOk(event, down)
            code in KeyMap.UP -> if (passThrough) false else onDir(Dir.UP, event, down)
            code in KeyMap.DOWN -> if (passThrough) false else onDir(Dir.DOWN, event, down)
            code in KeyMap.LEFT -> if (passThrough) false else onDir(Dir.LEFT, event, down)
            code in KeyMap.RIGHT -> if (passThrough) false else onDir(Dir.RIGHT, event, down)
            code in KeyMap.SHADE -> if (passThrough) false else onShadeKey(code, event, down)
            KeyMap.swipeDir(code) != null -> if (passThrough) false else onSwipeDigit(code, event, down)
            else -> false // клавиши набора текста идут штатной клавиатуре
        }
    }

    private fun checkCombo() {
        if (okDown && backDown) {
            handler.removeCallbacks(comboRunnable)
            handler.postDelayed(comboRunnable, Config.EMERGENCY_MS)
        }
    }

    private fun cancelCombo() {
        handler.removeCallbacks(comboRunnable)
    }

    private fun onBack(event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                backDown = true
                shadeOpen = false
                passThrough = false
                checkCombo()
            }
        } else {
            backDown = false
            cancelCombo()
        }
        return false // BACK работает как обычно
    }

    private fun onOk(event: KeyEvent, down: Boolean): Boolean {
        if (passThrough) {
            // Окно выбора клавиатуры: OK работает штатно, мы только следим за аварийной комбинацией.
            if (down) {
                if (event.repeatCount == 0) {
                    okDown = true
                    checkCombo()
                }
            } else {
                okDown = false
                cancelCombo()
                passThrough = false
            }
            return false
        }
        if (down) {
            if (event.repeatCount == 0) {
                okDown = true
                okLongFired = false
                okSuppressed = backDown
                checkCombo()
                if (!okSuppressed) {
                    handler.postDelayed(okLongRunnable, Config.OK_LONG_MS)
                }
            }
        } else {
            okDown = false
            cancelCombo()
            handler.removeCallbacks(okLongRunnable)
            if (!okLongFired && !okSuppressed && !comboFired) {
                performClick()
            }
        }
        return true
    }

    private fun onDir(dir: Dir, event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                handler.removeCallbacks(dirLongRunnable)
                stopMoving()
                pressedDir = dir
                dirLongFired = false
                dirComboUsed = false
                val h = held
                if (h != null && KeyMap.swipeDir(h.code) == dir &&
                    SystemClock.uptimeMillis() - h.time < Config.COMBO_WINDOW_MS
                ) {
                    // Цифра нажата чуть раньше стрелки: откатываем напечатанную цифру.
                    restoreText(h.snap)
                    repeatSwallow = h.code
                    held = null
                    dirComboUsed = true
                    pageSwipe(dir)
                } else {
                    handler.postDelayed(dirLongRunnable, Config.DIR_LONG_MS)
                }
            }
        } else {
            if (pressedDir == dir) {
                handler.removeCallbacks(dirLongRunnable)
                if (dirLongFired || dirComboUsed) {
                    stopMoving()
                } else {
                    shortPress(dir, true)
                }
                pressedDir = null
                dirComboUsed = false
            }
        }
        return true
    }

    /** Цифры 6/4/0/2: вместе с удержанной стрелкой дают свайп, сами по себе печатаются. */
    private fun onSwipeDigit(code: Int, event: KeyEvent, down: Boolean): Boolean {
        if (!down) {
            if (held?.code == code) held = null
            if (repeatSwallow == code) repeatSwallow = -1
            return swallowedKeys.remove(code)
        }
        if (event.repeatCount > 0) {
            return code in swallowedKeys || code == repeatSwallow
        }
        val dir = KeyMap.swipeDir(code)
        val pd = pressedDir
        if (pd != null && pd == dir) {
            swallowedKeys.add(code)
            dirComboUsed = true
            handler.removeCallbacks(dirLongRunnable)
            stopMoving()
            pageSwipe(pd)
            return true
        }
        held = HeldKey(code, SystemClock.uptimeMillis(), snapshotOf(focusedEditable()))
        return false
    }

    private fun onShadeKey(code: Int, event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            // Повторы удержанной семёрки глотаем: иначе в поле набегает много семёрок.
            if (event.repeatCount > 0) return true
            held = HeldKey(code, SystemClock.uptimeMillis(), snapshotOf(focusedEditable()))
            handler.removeCallbacks(key7Runnable)
            handler.postDelayed(key7Runnable, Config.KEY7_LONG_MS)
            return false
        }
        handler.removeCallbacks(key7Runnable)
        if (held?.code?.let { it in KeyMap.SHADE } == true) held = null
        return false
    }

    private fun onKey7Long() {
        val snap = held?.takeIf { it.code in KeyMap.SHADE }?.snap
        restoreText(snap)
        if (shadeOpen) {
            // Шторка уже открыта: раскрываем полную панель быстрых настроек.
            ShadeController.openQuickSettings(this)
        } else {
            shadeOpen = true
            // Небольшая задержка, чтобы успеть откатить напечатанную семёрку, пока поле ещё активно.
            handler.postDelayed({ ShadeController.open(this) }, 160L)
        }
    }

    // ------------------------------------------------------------------
    // Откат случайно напечатанной цифры
    // ------------------------------------------------------------------

    private fun focusedEditable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return findEditableFocused(root, 0)
    }

    private fun findEditableFocused(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (n.isEditable && n.isFocused) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findEditableFocused(c, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun snapshotOf(n: AccessibilityNodeInfo?): TextSnap? {
        if (n == null || n.isPassword) return null
        val txt = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        return TextSnap(txt, n.textSelectionStart, n.textSelectionEnd)
    }

    private fun restoreText(snap: TextSnap?) {
        if (snap == null) return
        applyText(snap)
        handler.postDelayed({ applyText(snap) }, 120L)
    }

    private fun applyText(snap: TextSnap) {
        val n = focusedEditable() ?: return
        if (n.isPassword) return
        val now = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        if (now == snap.text) return
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, snap.text)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (snap.selStart >= 0 && snap.selEnd >= 0) {
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, snap.selStart)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, snap.selEnd)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
    }

    // ------------------------------------------------------------------
    // Движение курсора и навигация
    // ------------------------------------------------------------------

    private fun startMoving(d: Dir) {
        movingDir = d
        moveStart = SystemClock.uptimeMillis()
        lastTick = moveStart
        handler.removeCallbacks(moveRunnable)
        handler.post(moveRunnable)
    }

    private fun stopMoving() {
        movingDir = null
        handler.removeCallbacks(moveRunnable)
    }

    private fun maybeScroll(dir: Dir, v: OverlayView) {
        if (dir != Dir.UP && dir != Dir.DOWN) return
        val now = SystemClock.uptimeMillis()
        if (now - lastScroll < Config.SCROLL_INTERVAL_MS) return
        val zone = Config.EDGE_ZONE_DP * density
        val atEdge = if (dir == Dir.DOWN) v.cursorY >= v.height - zone else v.cursorY <= zone
        if (!atEdge && !shadeOpen) return
        val nav = navigator ?: return
        lastScroll = now
        val p = v.cursorScreen()
        val res = nav.scroll(dir == Dir.DOWN, p.x, p.y, shadeOpen)
        if (res == ScrollResult.NONE && shadeOpen) {
            // Шторка не отдаёт прокручиваемый список: листаем настоящим жестом.
            swipeScroll(dir == Dir.DOWN)
        }
    }

    private fun shortPress(dir: Dir, allowScroll: Boolean) {
        val v = overlay ?: return
        val nav = navigator ?: return
        val cursor = v.cursorScreen()
        val fr = v.focusRect
        val cur: Rect? = when {
            fr == null -> null
            fr.contains(cursor.x, cursor.y) -> fr
            // Курсор уехал от рамки: ищем от точки, где он стоит.
            else -> Rect(cursor.x, cursor.y, cursor.x + 1, cursor.y + 1)
        }
        val item = nav.navigate(dir, cur, cursor, shadeOpen)
        if (item != null) {
            selectItem(item)
            return
        }
        if (allowScroll && (dir == Dir.UP || dir == Dir.DOWN)) {
            val res = nav.scroll(dir == Dir.DOWN, cursor.x, cursor.y, shadeOpen)
            if (res == ScrollResult.SCROLLED || (res == ScrollResult.NONE && shadeOpen)) {
                if (res == ScrollResult.NONE) swipeScroll(dir == Dir.DOWN)
                v.focusRect = null
                focusNode = null
                v.invalidate()
                handler.postDelayed({ afterScroll(dir) }, 400L)
            }
        }
    }

    /** После прокрутки выбираем элемент, ближайший к курсору. */
    private fun afterScroll(dir: Dir) {
        val v = overlay ?: return
        val nav = navigator ?: return
        val item = nav.navigate(dir, null, v.cursorScreen(), shadeOpen)
        if (item != null) selectItem(item)
    }

    private fun selectItem(item: NodeNavigator.Item) {
        val v = overlay ?: return
        focusNode = item.node
        v.focusRect = Rect(item.rect)
        v.moveCursorToScreen(item.rect.centerX(), item.rect.centerY())
        v.invalidate()
    }

    // ------------------------------------------------------------------
    // Клики и жесты
    // ------------------------------------------------------------------

    private fun performClick() {
        val v = overlay ?: return
        val p = v.cursorScreen()
        tapAt(p.x.toFloat(), p.y.toFloat(), Config.TAP_MS) { ok ->
            if (!ok) nodeAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun performRightClick() {
        val v = overlay ?: return
        val p = v.cursorScreen()
        tapAt(p.x.toFloat(), p.y.toFloat(), Config.LONG_TAP_MS) { ok ->
            if (!ok) nodeAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        }
    }

    private fun nodeAction(action: Int) {
        val v = overlay ?: return
        val node = focusNode ?: return
        val r = v.focusRect ?: return
        val p = v.cursorScreen()
        if (r.contains(p.x, p.y) && node.refresh()) node.performAction(action)
    }

    private fun tapAt(x: Float, y: Float, duration: Long, onResult: ((Boolean) -> Unit)? = null) {
        val path = Path()
        path.moveTo(x, y)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        injectGesture(gesture, duration, onResult)
    }

    private fun swipePath(x0: Float, y0: Float, x1: Float, y1: Float, ms: Long) {
        val path = Path()
        path.moveTo(x0, y0)
        path.lineTo(x1, y1)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, ms))
            .build()
        injectGesture(gesture, ms, null)
    }

    private fun opposite(d: Dir): Dir = when (d) {
        Dir.UP -> Dir.DOWN
        Dir.DOWN -> Dir.UP
        Dir.LEFT -> Dir.RIGHT
        Dir.RIGHT -> Dir.LEFT
    }

    /**
     * Свайп экрана «в сторону стрелки»: вправо+6 открывает правый экран, вниз+0 листает вниз.
     * Горизонтальные свайпы идут на высоте курсора, вертикальные на его горизонтали.
     */
    private fun pageSwipe(dir: Dir) {
        val v = overlay ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val w = v.width.toFloat()
        val h = v.height.toFloat()
        val c = v.cursorScreen()
        val cx = c.x.toFloat().coerceIn(loc[0] + 2f, loc[0] + w - 2f)
        val cy = c.y.toFloat().coerceIn(loc[1] + 2f, loc[1] + h - 2f)
        val finger = if (Config.SWIPE_FINGER_FOLLOWS_DIRECTION) dir else opposite(dir)
        when (finger) {
            Dir.LEFT -> swipePath(loc[0] + w * 0.85f, cy, loc[0] + w * 0.15f, cy, Config.SWIPE_MS)
            Dir.RIGHT -> swipePath(loc[0] + w * 0.15f, cy, loc[0] + w * 0.85f, cy, Config.SWIPE_MS)
            Dir.UP -> swipePath(cx, loc[1] + h * 0.70f, cx, loc[1] + h * 0.30f, Config.SWIPE_MS)
            Dir.DOWN -> swipePath(cx, loc[1] + h * 0.30f, cx, loc[1] + h * 0.70f, Config.SWIPE_MS)
        }
    }

    /** Прокрутка жестом (запасной вариант для шторки). forward = листаем вниз. */
    private fun swipeScroll(forward: Boolean) {
        val v = overlay ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val h = v.height.toFloat()
        val x = v.cursorScreen().x.toFloat()
        if (forward) {
            swipePath(x, loc[1] + h * 0.62f, x, loc[1] + h * 0.38f, 220L)
        } else {
            swipePath(x, loc[1] + h * 0.38f, x, loc[1] + h * 0.62f, 220L)
        }
    }

    /**
     * Выполняет жест. На время жеста слой становится «прозрачным для касаний»,
     * иначе синтетическое касание попало бы в наш же блокирующий слой.
     */
    private fun injectGesture(gesture: GestureDescription, totalMs: Long, onResult: ((Boolean) -> Unit)?) {
        val seq = ++touchSeq
        setTouchable(false)
        handler.postDelayed({
            if (seq != touchSeq) {
                onResult?.invoke(false)
                return@postDelayed
            }
            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (seq == touchSeq) setTouchable(true)
                    onResult?.invoke(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (seq == touchSeq) setTouchable(true)
                    onResult?.invoke(false)
                }
            }, handler)
            if (!ok) {
                if (seq == touchSeq) setTouchable(true)
                onResult?.invoke(false)
            }
        }, 60L)
        handler.postDelayed({
            if (seq == touchSeq) setTouchable(true)
        }, 60L + totalMs + 800L)
    }

    private fun setTouchable(touchable: Boolean) {
        val v = overlay ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm?.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // слой уже удалён
        }
    }
}
