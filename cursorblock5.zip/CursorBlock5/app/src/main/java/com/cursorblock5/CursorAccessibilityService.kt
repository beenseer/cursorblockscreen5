package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Ядро приложения: фильтрует физические кнопки, рисует курсор и блокирующий слой,
 * выполняет клики, навигацию, прокрутку и открытие шторки.
 */
class CursorAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CursorAccessibilityService? = null

        private const val SYSTEMUI = "com.android.systemui"
    }

    private class TextSnap(val text: String, val selStart: Int, val selEnd: Int)

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: OverlayView? = null
    private var navigator: NodeNavigator? = null
    private var density = 1f

    @Volatile
    var active = false
        private set

    // ---- D-pad ----
    private var pressedDir: Dir? = null
    private var dirLongFired = false
    private var movingDir: Dir? = null
    private var moveStart = 0L
    private var lastTick = 0L
    private var lastScroll = 0L

    // ---- OK / BACK ----
    private var okDown = false
    private var backDown = false
    private var okLongFired = false
    private var okSuppressed = false
    private var comboFired = false
    private var swallowBackUp = false

    // ---- кнопка 7 ----
    private var key7DownPassed = false
    private var key7Consume = false
    private var key7Fired = false
    private var key7Snap: TextSnap? = null

    private var focusNode: AccessibilityNodeInfo? = null
    private var shadeOpen = false

    private val dirLongRunnable = Runnable {
        val d = pressedDir
        if (d != null) {
            dirLongFired = true
            startMoving(d)
        }
    }

    private val okLongRunnable = Runnable {
        okLongFired = true
        performRightClick()
    }

    private val key7Runnable = Runnable { onKey7Long() }

    private val idleRunnable = Runnable { disableMode() }

    private val comboRunnable = Runnable {
        comboFired = true
        swallowBackUp = backDown
        disableMode()
    }

    private val moveRunnable = object : Runnable {
        override fun run() {
            val dir = movingDir ?: return
            val v = overlay ?: return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastTick).coerceAtLeast(1L) / 1000f
            lastTick = now
            val t = ((now - moveStart).toFloat() / Config.ACCEL_MS).coerceIn(0f, 1f)
            val eased = t * t * (3f - 2f * t)
            val speed = (Config.MIN_SPEED_DP + (Config.MAX_SPEED_DP - Config.MIN_SPEED_DP) * eased) * density
            val step = speed * dt
            var x = v.cursorX
            var y = v.cursorY
            when (dir) {
                Dir.UP -> y -= step
                Dir.DOWN -> y += step
                Dir.LEFT -> x -= step
                Dir.RIGHT -> x += step
            }
            v.moveCursor(x, y)
            resetIdle()
            maybeScroll(dir, v)
            handler.postDelayed(this, Config.TICK_MS)
        }
    }

    // ------------------------------------------------------------------
    // Жизненный цикл службы
    // ------------------------------------------------------------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        navigator = NodeNavigator(this)
        density = resources.displayMetrics.density
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!active || event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (shadeOpen && pkg != null && pkg != SYSTEMUI && pkg != packageName) {
                shadeOpen = false
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        disableMode()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        disableMode()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Включение и выключение режима
    // ------------------------------------------------------------------

    fun enableMode() {
        if (active) return
        val manager = wm ?: return
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            manager.addView(v, lp)
        } catch (e: Exception) {
            return
        }
        overlay = v
        resetKeyState()
        shadeOpen = false
        active = true
        try {
            startForegroundService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // уведомление не критично для работы режима
        }
        resetIdle()
    }

    fun disableMode() {
        handler.removeCallbacksAndMessages(null)
        val v = overlay
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // слой уже удалён
            }
        }
        overlay = null
        focusNode = null
        resetKeyState()
        shadeOpen = false
        active = false
        try {
            stopService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // служба уже остановлена
        }
    }

    private fun resetKeyState() {
        pressedDir = null
        dirLongFired = false
        movingDir = null
        okDown = false
        backDown = false
        okLongFired = false
        okSuppressed = false
        comboFired = false
        key7DownPassed = false
        key7Consume = false
        key7Fired = false
        key7Snap = null
    }

    private fun resetIdle() {
        handler.removeCallbacks(idleRunnable)
        handler.postDelayed(idleRunnable, Config.IDLE_TIMEOUT_MS)
    }

    // ------------------------------------------------------------------
    // Фильтр физических кнопок
    // ------------------------------------------------------------------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN

        // После аварийного отключения глотаем отпускание BACK, чтобы не было лишнего «назад».
        if (swallowBackUp && code == KeyMap.BACK && !down) {
            swallowBackUp = false
            return true
        }
        if (!active) return false

        return when {
            code == KeyMap.BACK -> onBack(event, down)
            code in KeyMap.OK -> onOk(event, down)
            code in KeyMap.UP -> onDir(Dir.UP, event, down)
            code in KeyMap.DOWN -> onDir(Dir.DOWN, event, down)
            code in KeyMap.LEFT -> onDir(Dir.LEFT, event, down)
            code in KeyMap.RIGHT -> onDir(Dir.RIGHT, event, down)
            code == KeyMap.SHADE -> onShadeKey(event, down)
            else -> false // клавиши набора текста идут штатной клавиатуре
        }
    }

    private fun checkCombo() {
        if (okDown && backDown) {
            handler.removeCallbacks(comboRunnable)
            handler.postDelayed(comboRunnable, Config.EMERGENCY_MS)
        }
    }

    private fun cancelCombo() {
        handler.removeCallbacks(comboRunnable)
    }

    private fun onBack(event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                backDown = true
                shadeOpen = false
                checkCombo()
            }
        } else {
            backDown = false
            cancelCombo()
        }
        return false // BACK работает как обычно
    }

    private fun onOk(event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                okDown = true
                okLongFired = false
                okSuppressed = backDown
                checkCombo()
                if (!okSuppressed) {
                    handler.postDelayed(okLongRunnable, Config.OK_LONG_MS)
                }
            }
        } else {
            okDown = false
            cancelCombo()
            handler.removeCallbacks(okLongRunnable)
            if (!okLongFired && !okSuppressed && !comboFired) {
                performClick()
            }
        }
        return true
    }

    private fun onDir(dir: Dir, event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                handler.removeCallbacks(dirLongRunnable)
                stopMoving()
                pressedDir = dir
                dirLongFired = false
                handler.postDelayed(dirLongRunnable, Config.DIR_LONG_MS)
            }
        } else {
            if (pressedDir == dir) {
                handler.removeCallbacks(dirLongRunnable)
                if (dirLongFired) {
                    stopMoving()
                } else {
                    shortPress(dir, true)
                }
                pressedDir = null
            }
        }
        return true
    }

    private fun onShadeKey(event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                key7Fired = false
                val editable = focusedEditable()
                key7Snap = snapshotOf(editable)
                // Если нет поля ввода, кнопка 7 ничего не печатает: поглощаем её.
                // Если поле есть, пропускаем нажатие, а при длинном удержании откатываем текст.
                key7Consume = editable == null
                key7DownPassed = !key7Consume
                handler.removeCallbacks(key7Runnable)
                handler.postDelayed(key7Runnable, Config.KEY7_LONG_MS)
            }
            return key7Consume || key7Fired
        }
        handler.removeCallbacks(key7Runnable)
        val consume = key7Consume
        val passed = key7DownPassed
        key7Consume = false
        key7DownPassed = false
        key7Fired = false
        key7Snap = null
        // Если нажатие было передано приложению, отпускание тоже передаём.
        return consume && !passed
    }

    private fun onKey7Long() {
        key7Fired = true
        if (key7DownPassed) restoreText()
        shadeOpen = true
        ShadeController.open(this)
        resetIdle()
    }

    private fun focusedEditable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return null
        return if (n.isEditable) n else null
    }

    private fun snapshotOf(n: AccessibilityNodeInfo?): TextSnap? {
        if (n == null || n.isPassword) return null
        val txt = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        return TextSnap(txt, n.textSelectionStart, n.textSelectionEnd)
    }

    private fun restoreText() {
        val snap = key7Snap ?: return
        val n = focusedEditable() ?: return
        if (n.isPassword) return
        val now = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        if (now == snap.text) return
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, snap.text)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (snap.selStart >= 0 && snap.selEnd >= 0) {
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, snap.selStart)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, snap.selEnd)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
    }

    // ------------------------------------------------------------------
    // Движение курсора и навигация
    // ------------------------------------------------------------------

    private fun startMoving(d: Dir) {
        movingDir = d
        moveStart = SystemClock.uptimeMillis()
        lastTick = moveStart
        handler.removeCallbacks(moveRunnable)
        handler.post(moveRunnable)
    }

    private fun stopMoving() {
        movingDir = null
        handler.removeCallbacks(moveRunnable)
    }

    private fun maybeScroll(dir: Dir, v: OverlayView) {
        if (dir != Dir.UP && dir != Dir.DOWN) return
        val now = SystemClock.uptimeMillis()
        if (now - lastScroll < Config.SCROLL_INTERVAL_MS) return
        val zone = Config.EDGE_ZONE_DP * density
        val atEdge = if (dir == Dir.DOWN) v.cursorY >= v.height - zone else v.cursorY <= zone
        if (!atEdge && !shadeOpen) return
        val p = v.cursorScreen()
        val nav = navigator ?: return
        if (nav.scroll(dir == Dir.DOWN, p.x, p.y, shadeOpen)) {
            lastScroll = now
        }
    }

    private fun shortPress(dir: Dir, allowScroll: Boolean) {
        val v = overlay ?: return
        val nav = navigator ?: return
        val item = nav.navigate(dir, v.focusRect, v.cursorScreen())
        if (item != null) {
            selectItem(item)
            return
        }
        if (allowScroll && (dir == Dir.UP || dir == Dir.DOWN)) {
            if (nav.scroll(dir == Dir.DOWN, null, null, shadeOpen)) {
                handler.postDelayed({ shortPress(dir, false) }, 350L)
            }
        }
        resetIdle()
    }

    private fun selectItem(item: NodeNavigator.Item) {
        val v = overlay ?: return
        focusNode = item.node
        v.focusRect = Rect(item.rect)
        v.moveCursorToScreen(item.rect.centerX(), item.rect.centerY())
        v.invalidate()
        resetIdle()
    }

    // ------------------------------------------------------------------
    // Клики
    // ------------------------------------------------------------------

    private fun performClick() {
        resetIdle()
        val v = overlay ?: return
        val p = v.cursorScreen()
        val node = focusNode
        val r = v.focusRect
        if (node != null && r != null && r.contains(p.x, p.y)) {
            if (node.refresh() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        }
        dispatchPoint(p.x.toFloat(), p.y.toFloat(), Config.TAP_MS)
    }

    private fun performRightClick() {
        resetIdle()
        val v = overlay ?: return
        val p = v.cursorScreen()
        val node = focusNode
        val r = v.focusRect
        if (node != null && r != null && r.contains(p.x, p.y)) {
            if (node.refresh() && node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return
        }
        dispatchPoint(p.x.toFloat(), p.y.toFloat(), Config.LONG_TAP_MS)
    }

    /**
     * Жест в точке экрана. На время жеста слой становится «прозрачным для касаний»,
     * иначе синтетическое касание попало бы в наш же блокирующий слой.
     */
    private fun dispatchPoint(x: Float, y: Float, duration: Long) {
        setTouchable(false)
        handler.postDelayed({
            val path = Path()
            path.moveTo(x, y)
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
                .build()
            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    setTouchable(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    setTouchable(true)
                }
            }, handler)
            if (!ok) setTouchable(true)
        }, 60L)
        handler.postDelayed({ setTouchable(true) }, 60L + duration + 600L)
    }

    private fun setTouchable(touchable: Boolean) {
        val v = overlay ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm?.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // слой уже удалён
        }
    }
}
