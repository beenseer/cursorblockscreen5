package com.cursorblock5

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Ядро приложения: фильтрует физические кнопки, рисует курсор и блокирующий слой,
 * выполняет клики, навигацию, прокрутку, свайпы и открытие шторки.
 */
class CursorAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CursorAccessibilityService? = null

        private const val SYSTEMUI = "com.android.systemui"
        private const val ANDROID_PKG = "android"
    }

    private class TextSnap(val text: String, val selStart: Int, val selEnd: Int)

    /** Цифровая клавиша, нажатие которой уже ушло в приложение (нужно для отката текста). */
    private class HeldKey(val code: Int, val time: Long, val snap: TextSnap?)

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: OverlayView? = null
    private var navigator: NodeNavigator? = null
    private var density = 1f

    @Volatile
    var active = false
        private set

    // ---- D-pad ----
    private var pressedDir: Dir? = null
    private var dirLongFired = false
    private var dirComboUsed = false
    private var movingDir: Dir? = null
    private var moveStart = 0L
    private var lastTick = 0L
    private var lastScroll = 0L
    private var edgeSince = 0L

    // ---- OK / BACK ----
    private var okDown = false
    private var backDown = false
    private var okLongFired = false
    private var okSuppressed = false
    private var comboFired = false
    private var swallowBackUp = false

    // ---- цифры: 6/4/8/2 (свайпы) и 0 (шторка) вместе со стрелкой ----
    private var held: HeldKey? = null
    private val swallowedKeys = HashSet<Int>()
    private var repeatSwallow = -1

    // ---- состояние ----
    private var focusNode: AccessibilityNodeInfo? = null
    private var shadeRequestedAt = 0L
    private var shadeCacheAt = 0L
    private var shadeCacheVal = false
    private var passThrough = false
    private var passThroughUntil = 0L
    private var passThroughSince = 0L
    private var touchSeq = 0
    private var dragBusy = false

    private val dirLongRunnable = Runnable {
        val d = pressedDir
        if (d != null && !dirComboUsed) {
            dirLongFired = true
            startMoving(d)
        }
    }

    private val okLongRunnable = Runnable {
        okLongFired = true
        performRightClick()
    }

    private val shadeComboRunnable = Runnable { openShadeOrQuickSettings() }

    private val comboRunnable = Runnable {
        comboFired = true
        swallowBackUp = backDown
        disableMode()
    }

    private val moveRunnable = object : Runnable {
        override fun run() {
            val dir = movingDir ?: return
            val v = overlay ?: return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastTick).coerceAtLeast(1L) / 1000f
            lastTick = now
            val t = ((now - moveStart).toFloat() / Config.ACCEL_MS).coerceIn(0f, 1f)
            val eased = t * t * (3f - 2f * t)
            val speed = (Config.MIN_SPEED_DP + (Config.MAX_SPEED_DP - Config.MIN_SPEED_DP) * eased) * density
            val step = speed * dt
            var x = v.cursorX
            var y = v.cursorY
            when (dir) {
                Dir.UP -> y -= step
                Dir.DOWN -> y += step
                Dir.LEFT -> x -= step
                Dir.RIGHT -> x += step
            }
            v.moveCursor(x, y)
            tickScroll(dir, v, now)
            handler.postDelayed(this, Config.TICK_MS)
        }
    }

    // ------------------------------------------------------------------
    // Жизненный цикл службы
    // ------------------------------------------------------------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        navigator = NodeNavigator(this)
        density = resources.displayMetrics.density
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!active || event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            if (pkg == SYSTEMUI || pkg == packageName || pkg == ANDROID_PKG) return
            // Открылось обычное приложение: окно выбора клавиатуры закрыто.
            if (passThrough && SystemClock.uptimeMillis() - passThroughSince > 1500L) {
                passThrough = false
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        disableMode()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        disableMode()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Включение и выключение режима
    // ------------------------------------------------------------------

    fun enableMode() {
        if (active) return
        val manager = wm ?: return
        val v = OverlayView(this)
        v.onHoldComplete = { handler.post { disableMode() } }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            manager.addView(v, lp)
        } catch (e: Exception) {
            return
        }
        overlay = v
        resetKeyState()
        active = true
        try {
            startForegroundService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // уведомление не критично для работы режима
        }
    }

    fun disableMode() {
        handler.removeCallbacksAndMessages(null)
        val v = overlay
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // слой уже удалён
            }
        }
        overlay = null
        focusNode = null
        resetKeyState()
        passThrough = false
        dragBusy = false
        active = false
        try {
            stopService(Intent(this, ModeService::class.java))
        } catch (e: Exception) {
            // служба уже остановлена
        }
    }

    private fun resetKeyState() {
        pressedDir = null
        dirLongFired = false
        dirComboUsed = false
        movingDir = null
        edgeSince = 0L
        okDown = false
        backDown = false
        okLongFired = false
        okSuppressed = false
        comboFired = false
        held = null
        swallowedKeys.clear()
        repeatSwallow = -1
        shadeRequestedAt = 0L
        shadeCacheAt = 0L
        touchSeq++
    }

    /** Вызывается, когда открыто системное окно выбора клавиатуры. */
    fun beginPassThrough() {
        if (!active) return
        handler.removeCallbacks(dirLongRunnable)
        stopMoving()
        pressedDir = null
        dirComboUsed = false
        passThrough = true
        passThroughSince = SystemClock.uptimeMillis()
        passThroughUntil = passThroughSince + 60_000L
    }

    // ------------------------------------------------------------------
    // Шторка
    // ------------------------------------------------------------------

    /** Шторка открыта? Определяем по окнам: SystemUI растягивается на весь экран. */
    private fun shadeOpenNow(fresh: Boolean = false): Boolean {
        val now = SystemClock.uptimeMillis()
        if (fresh || now - shadeCacheAt > 250L) {
            shadeCacheVal = navigator?.isShadeOpen() ?: false
            shadeCacheAt = now
        }
        return shadeCacheVal || now - shadeRequestedAt < 1200L
    }

    private fun openShadeOrQuickSettings() {
        if (shadeOpenNow(true)) {
            // Шторка уже открыта: раскрываем полную панель быстрых настроек.
            ShadeController.openQuickSettings(this)
        } else {
            shadeRequestedAt = SystemClock.uptimeMillis()
            ShadeController.open(this)
        }
    }

    private fun startShadeCombo() {
        handler.removeCallbacks(shadeComboRunnable)
        handler.postDelayed(shadeComboRunnable, Config.SHADE_COMBO_MS)
    }

    private fun cancelShadeCombo() {
        handler.removeCallbacks(shadeComboRunnable)
    }

    // ------------------------------------------------------------------
    // Фильтр физических кнопок
    // ------------------------------------------------------------------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN

        // После аварийного отключения глотаем отпускание BACK, чтобы не было лишнего «назад».
        if (swallowBackUp && code == KeyMap.BACK && !down) {
            swallowBackUp = false
            return true
        }
        if (!active) return false

        if (passThrough && SystemClock.uptimeMillis() > passThroughUntil) passThrough = false

        return when {
            code == KeyMap.BACK -> onBack(event, down)
            code in KeyMap.OK -> onOk(event, down)
            code in KeyMap.UP -> if (passThrough) false else onDir(Dir.UP, event, down)
            code in KeyMap.DOWN -> if (passThrough) false else onDir(Dir.DOWN, event, down)
            code in KeyMap.LEFT -> if (passThrough) false else onDir(Dir.LEFT, event, down)
            code in KeyMap.RIGHT -> if (passThrough) false else onDir(Dir.RIGHT, event, down)
            code in KeyMap.SHADE_DIGITS || KeyMap.swipeDir(code) != null ->
                if (passThrough) false else onComboDigit(code, event, down)
            else -> false // клавиши набора текста идут штатной клавиатуре
        }
    }

    private fun checkCombo() {
        if (okDown && backDown) {
            handler.removeCallbacks(comboRunnable)
            handler.postDelayed(comboRunnable, Config.EMERGENCY_MS)
        }
    }

    private fun cancelCombo() {
        handler.removeCallbacks(comboRunnable)
    }

    private fun onBack(event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                backDown = true
                shadeRequestedAt = 0L
                shadeCacheAt = 0L
                passThrough = false
                checkCombo()
            }
        } else {
            backDown = false
            cancelCombo()
        }
        return false // BACK работает как обычно
    }

    private fun onOk(event: KeyEvent, down: Boolean): Boolean {
        if (passThrough) {
            // Окно выбора клавиатуры: OK работает штатно, мы только следим за аварийной комбинацией.
            if (down) {
                if (event.repeatCount == 0) {
                    okDown = true
                    checkCombo()
                }
            } else {
                okDown = false
                cancelCombo()
                passThrough = false
            }
            return false
        }
        if (down) {
            if (event.repeatCount == 0) {
                okDown = true
                okLongFired = false
                okSuppressed = backDown
                checkCombo()
                if (!okSuppressed) {
                    handler.postDelayed(okLongRunnable, Config.OK_LONG_MS)
                }
            }
        } else {
            okDown = false
            cancelCombo()
            handler.removeCallbacks(okLongRunnable)
            if (!okLongFired && !okSuppressed && !comboFired) {
                performClick()
            }
        }
        return true
    }

    private fun comboDirOf(code: Int): Dir? =
        if (code in KeyMap.SHADE_DIGITS) Dir.DOWN else KeyMap.swipeDir(code)

    private fun beginDirCombo() {
        dirComboUsed = true
        handler.removeCallbacks(dirLongRunnable)
        stopMoving()
    }

    private fun onDir(dir: Dir, event: KeyEvent, down: Boolean): Boolean {
        if (down) {
            if (event.repeatCount == 0) {
                handler.removeCallbacks(dirLongRunnable)
                stopMoving()
                pressedDir = dir
                dirLongFired = false
                dirComboUsed = false
                val h = held
                if (h != null && comboDirOf(h.code) == dir &&
                    SystemClock.uptimeMillis() - h.time < Config.COMBO_WINDOW_MS
                ) {
                    // Цифра нажата чуть раньше стрелки: откатываем напечатанную цифру.
                    restoreText(h.snap)
                    repeatSwallow = h.code
                    held = null
                    beginDirCombo()
                    if (h.code in KeyMap.SHADE_DIGITS) startShadeCombo() else pageSwipe(dir)
                } else {
                    handler.postDelayed(dirLongRunnable, Config.DIR_LONG_MS)
                }
            }
        } else {
            if (pressedDir == dir) {
                handler.removeCallbacks(dirLongRunnable)
                cancelShadeCombo()
                if (dirLongFired || dirComboUsed) {
                    stopMoving()
                } else {
                    shortPress(dir, true)
                }
                pressedDir = null
                dirComboUsed = false
            }
        }
        return true
    }

    /**
     * Цифры 6/4/8/2: вместе с удержанной стрелкой дают свайп, 0: вместе со стрелкой вниз
     * открывает шторку. Сами по себе печатаются как обычно.
     */
    private fun onComboDigit(code: Int, event: KeyEvent, down: Boolean): Boolean {
        val isShade = code in KeyMap.SHADE_DIGITS
        if (!down) {
            if (held?.code == code) held = null
            if (repeatSwallow == code) repeatSwallow = -1
            if (isShade) cancelShadeCombo()
            return swallowedKeys.remove(code)
        }
        if (event.repeatCount > 0) {
            return code in swallowedKeys || code == repeatSwallow
        }
        val dir = comboDirOf(code)
        val pd = pressedDir
        if (pd != null && pd == dir) {
            swallowedKeys.add(code)
            beginDirCombo()
            if (isShade) startShadeCombo() else pageSwipe(pd)
            return true
        }
        held = HeldKey(code, SystemClock.uptimeMillis(), snapshotOf(focusedEditable()))
        return false
    }

    // ------------------------------------------------------------------
    // Откат случайно напечатанной цифры
    // ------------------------------------------------------------------

    private fun focusedEditable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return findEditableFocused(root, 0)
    }

    private fun findEditableFocused(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (n.isEditable && n.isFocused) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findEditableFocused(c, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun snapshotOf(n: AccessibilityNodeInfo?): TextSnap? {
        if (n == null || n.isPassword) return null
        val txt = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        return TextSnap(txt, n.textSelectionStart, n.textSelectionEnd)
    }

    private fun restoreText(snap: TextSnap?) {
        if (snap == null) return
        applyText(snap)
        handler.postDelayed({ applyText(snap) }, 120L)
    }

    private fun applyText(snap: TextSnap) {
        val n = focusedEditable() ?: return
        if (n.isPassword) return
        val now = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        if (now == snap.text) return
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, snap.text)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (snap.selStart >= 0 && snap.selEnd >= 0) {
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, snap.selStart)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, snap.selEnd)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
    }

    // ------------------------------------------------------------------
    // Движение курсора, навигация, прокрутка у края
    // ------------------------------------------------------------------

    private fun startMoving(d: Dir) {
        movingDir = d
        moveStart = SystemClock.uptimeMillis()
        lastTick = moveStart
        edgeSince = 0L
        handler.removeCallbacks(moveRunnable)
        handler.post(moveRunnable)
    }

    private fun stopMoving() {
        movingDir = null
        edgeSince = 0L
        handler.removeCallbacks(moveRunnable)
    }

    /**
     * Удержание стрелки у края экрана прокручивает содержимое в эту сторону
     * (список, страница браузера, увеличенная картинка). В шторке вертикальная
     * прокрутка идёт сразу, без дойти до края.
     */
    private fun tickScroll(dir: Dir, v: OverlayView, now: Long) {
        val zone = Config.EDGE_ZONE_DP * density
        val atEdge = when (dir) {
            Dir.DOWN -> v.cursorY >= v.height - zone
            Dir.UP -> v.cursorY <= zone
            Dir.RIGHT -> v.cursorX >= v.width - zone
            Dir.LEFT -> v.cursorX <= zone
        }
        if (atEdge) {
            if (edgeSince == 0L) edgeSince = now
        } else {
            edgeSince = 0L
        }
        if (now - lastScroll < Config.SCROLL_INTERVAL_MS) return
        val vertical = dir == Dir.UP || dir == Dir.DOWN
        val dwellOk = atEdge && now - edgeSince >= Config.EDGE_DWELL_MS
        if (!dwellOk && !(vertical && shadeOpenNow())) return
        lastScroll = now
        doScroll(dir, v)
    }

    private fun doScroll(dir: Dir, v: OverlayView) {
        val nav = navigator ?: return
        val p = v.cursorScreen()
        val res = nav.scroll(dir, p.x, p.y, shadeOpenNow())
        // Узел прокрутки не найден вообще (картинка, самописный список): листаем жестом.
        if (res == ScrollResult.NONE && !dragBusy) dragScroll(dir)
    }

    private fun shortPress(dir: Dir, allowScroll: Boolean) {
        val v = overlay ?: return
        val nav = navigator ?: return
        val shade = shadeOpenNow(true)
        val cursor = v.cursorScreen()
        val fr = v.focusRect
        val cur: Rect? = when {
            fr == null -> null
            fr.contains(cursor.x, cursor.y) -> fr
            // Курсор уехал от рамки: ищем от точки, где он стоит.
            else -> Rect(cursor.x, cursor.y, cursor.x + 1, cursor.y + 1)
        }
        val item = nav.navigate(dir, cur, cursor, shade)
        if (item != null) {
            selectItem(item)
            return
        }
        if (allowScroll && (dir == Dir.UP || dir == Dir.DOWN)) {
            val res = nav.scroll(dir, cursor.x, cursor.y, shade)
            var moved = false
            if (res == ScrollResult.SCROLLED) {
                moved = true
            } else if (res == ScrollResult.NONE && shade && !dragBusy) {
                dragScroll(dir)
                moved = true
            }
            if (moved) {
                v.focusRect = null
                focusNode = null
                v.invalidate()
                handler.postDelayed({ afterScroll(dir) }, 450L)
            }
        }
    }

    /** После прокрутки выбираем элемент, ближайший к курсору. */
    private fun afterScroll(dir: Dir) {
        val v = overlay ?: return
        val nav = navigator ?: return
        val item = nav.navigate(dir, null, v.cursorScreen(), shadeOpenNow(true))
        if (item != null) selectItem(item)
    }

    private fun selectItem(item: NodeNavigator.Item) {
        val v = overlay ?: return
        focusNode = item.node
        v.focusRect = Rect(item.rect)
        v.moveCursorToScreen(item.rect.centerX(), item.rect.centerY())
        v.invalidate()
    }

    // ------------------------------------------------------------------
    // Клики и жесты
    // ------------------------------------------------------------------

    private fun performClick() {
        val v = overlay ?: return
        val p = v.cursorScreen()
        tapAt(p.x.toFloat(), p.y.toFloat(), Config.TAP_MS) { ok ->
            if (!ok) nodeAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun performRightClick() {
        val v = overlay ?: return
        val p = v.cursorScreen()
        tapAt(p.x.toFloat(), p.y.toFloat(), Config.LONG_TAP_MS) { ok ->
            if (!ok) nodeAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        }
    }

    private fun nodeAction(action: Int) {
        val v = overlay ?: return
        val node = focusNode ?: return
        val r = v.focusRect ?: return
        val p = v.cursorScreen()
        if (r.contains(p.x, p.y) && node.refresh()) node.performAction(action)
    }

    private fun tapAt(x: Float, y: Float, duration: Long, onResult: ((Boolean) -> Unit)? = null) {
        val path = Path()
        path.moveTo(x, y)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        injectGesture(gesture, duration, onResult)
    }

    private fun swipePath(
        x0: Float, y0: Float, x1: Float, y1: Float, ms: Long,
        onResult: ((Boolean) -> Unit)? = null
    ) {
        val path = Path()
        path.moveTo(x0, y0)
        path.lineTo(x1, y1)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, ms))
            .build()
        injectGesture(gesture, ms, onResult)
    }

    private fun opposite(d: Dir): Dir = when (d) {
        Dir.UP -> Dir.DOWN
        Dir.DOWN -> Dir.UP
        Dir.LEFT -> Dir.RIGHT
        Dir.RIGHT -> Dir.LEFT
    }

    /**
     * Свайп пальцем, начатый в точке курсора, длиной SWIPE_DISTANCE экрана.
     * Вниз+8 тянет палец вниз (так выдвигается шторка, если курсор стоит у верха экрана),
     * вправо+6 открывает следующую страницу (палец идёт справа налево).
     * Работает везде: в приложениях, в шторке, на заблокированном экране.
     */
    private fun pageSwipe(dir: Dir) {
        val v = overlay ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val w = v.width.toFloat()
        val h = v.height.toFloat()
        val c = v.cursorScreen()
        val minX = loc[0] + 1f
        val maxX = loc[0] + w - 1f
        val minY = loc[1] + 1f
        val maxY = loc[1] + h - 1f
        val sx = c.x.toFloat().coerceIn(minX, maxX)
        val sy = c.y.toFloat().coerceIn(minY, maxY)
        val horizontal = dir == Dir.LEFT || dir == Dir.RIGHT
        val follows = if (horizontal) {
            Config.SWIPE_H_FINGER_FOLLOWS_DIRECTION
        } else {
            Config.SWIPE_V_FINGER_FOLLOWS_DIRECTION
        }
        val finger = if (follows) dir else opposite(dir)
        val dx = w * Config.SWIPE_DISTANCE
        val dy = h * Config.SWIPE_DISTANCE
        var ex = sx
        var ey = sy
        when (finger) {
            Dir.LEFT -> ex = (sx - dx).coerceAtLeast(minX)
            Dir.RIGHT -> ex = (sx + dx).coerceAtMost(maxX)
            Dir.UP -> ey = (sy - dy).coerceAtLeast(minY)
            Dir.DOWN -> ey = (sy + dy).coerceAtMost(maxY)
        }
        swipePath(sx, sy, ex, ey, Config.SWIPE_MS)
    }

    /**
     * Прокрутка перетаскиванием (запасной вариант, когда узлов прокрутки нет).
     * dir: в какую сторону должно уехать содержимое; палец идёт в обратную.
     */
    private fun dragScroll(dir: Dir) {
        val v = overlay ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val w = v.width.toFloat()
        val h = v.height.toFloat()
        val c = v.cursorScreen()
        val cx = c.x.toFloat().coerceIn(loc[0] + 1f, loc[0] + w - 1f)
        val cy = c.y.toFloat().coerceIn(loc[1] + 1f, loc[1] + h - 1f)
        dragBusy = true
        handler.postDelayed({ dragBusy = false }, 900L)
        val done: (Boolean) -> Unit = { dragBusy = false }
        when (opposite(dir)) {
            Dir.UP -> swipePath(cx, loc[1] + h * 0.70f, cx, loc[1] + h * 0.46f, 260L, done)
            Dir.DOWN -> swipePath(cx, loc[1] + h * 0.46f, cx, loc[1] + h * 0.70f, 260L, done)
            Dir.LEFT -> swipePath(loc[0] + w * 0.70f, cy, loc[0] + w * 0.46f, cy, 260L, done)
            Dir.RIGHT -> swipePath(loc[0] + w * 0.46f, cy, loc[0] + w * 0.70f, cy, 260L, done)
        }
    }

    /**
     * Выполняет жест. На время жеста слой становится «прозрачным для касаний»,
     * иначе синтетическое касание попало бы в наш же блокирующий слой.
     */
    private fun injectGesture(gesture: GestureDescription, totalMs: Long, onResult: ((Boolean) -> Unit)?) {
        val seq = ++touchSeq
        setTouchable(false)
        handler.postDelayed({
            if (seq != touchSeq) {
                onResult?.invoke(false)
                return@postDelayed
            }
            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (seq == touchSeq) setTouchable(true)
                    onResult?.invoke(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (seq == touchSeq) setTouchable(true)
                    onResult?.invoke(false)
                }
            }, handler)
            if (!ok) {
                if (seq == touchSeq) setTouchable(true)
                onResult?.invoke(false)
            }
        }, 60L)
        handler.postDelayed({
            if (seq == touchSeq) setTouchable(true)
        }, 60L + totalMs + 800L)
    }

    private fun setTouchable(touchable: Boolean) {
        val v = overlay ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm?.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // слой уже удалён
        }
    }
}
